package runner;

import org.testng.annotations.DataProvider;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;
import stepDefinition.BaseClass;

@CucumberOptions(features = { "src/test/java/feature" }, glue = "stepDefinition", monochrome = true, publish = true,
		// tags="@Sanity") //execute one scenario
		// tags="not @Sanity")//ignore the scenario from execution
		// tags="@Smoke and @Regression") //check for both the conditions to be
		// satisfied
		tags = "@Smoke or @Regression")//If either of the condition is satisfied 
public class Runner extends BaseClass {

	/*
	 * @DataProvider(parallel = true) public Object[][] scenarios() { return
	 * super.scenarios(); }
	 */
}
