package base;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Parameters;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

public class ProjectSpecificMethods {

	public ChromeDriver driver;
	public Properties prop;// global variable
	public static ExtentReports extent;
	public String testName, testDesc, author, category;
	public static ExtentTest test;

	@Parameters("language")
	@BeforeMethod
	public void preCondition(String language) throws IOException {
		FileInputStream fis = new FileInputStream("./src/main/resources/" + language + ".properties");
		prop = new Properties();
		prop.load(fis);
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://leaftaps.com/opentaps/");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
	}

	@BeforeSuite
	public void startReport() {
		ExtentHtmlReporter reporter = new ExtentHtmlReporter("./reports/result.html");
		reporter.setAppendExisting(true);
		extent = new ExtentReports();
		extent.attachReporter(reporter);

	}

	@BeforeClass
	public void testDetails() {
		test = extent.createTest(testName, testDesc);
		test.assignAuthor(author);
		test.assignCategory(category);
	}

	public void reportStep(String status, String message) throws IOException {
		if (status.equalsIgnoreCase("pass")) {
			test.pass(message,
					MediaEntityBuilder.createScreenCaptureFromPath(".././snap/shot" + takeSnap() + ".jpg").build());
		} else if (status.equalsIgnoreCase("fail")) {
			test.fail(message,
					MediaEntityBuilder.createScreenCaptureFromPath(".././snap/shot" + takeSnap() + ".jpg").build());
		}

	}

	public int takeSnap() throws IOException {
		int random = (int) (Math.random() * 999);
		File screenshotAs = driver.getScreenshotAs(OutputType.FILE);
		File destnfile = new File("./snap/shot" + random + ".jpg");// empty
		FileUtils.copyFile(screenshotAs, destnfile);
		return random;
	}

	@AfterSuite
	public void endReport() {
		extent.flush();
	}

	@AfterMethod
	public void postConditions() {
		driver.close();
	}

}
