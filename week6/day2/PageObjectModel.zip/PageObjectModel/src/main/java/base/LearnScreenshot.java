package base;

import java.io.File;
import java.io.IOException;
import java.time.Duration;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class LearnScreenshot {
public ChromeDriver driver;
	
	
	
	
	public static void main(String[] args) throws IOException {
	   ChromeDriver driver =new ChromeDriver();
	    driver.get("http://leaftaps.com/opentaps/");
	    driver.manage().window().maximize();
	    driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	    
	    
	    WebElement uname = driver.findElement(By.id("username"));
	    uname.sendKeys("demo");
	    
	    int random =(int) (Math.random()*999);	
	    
	    File screenshotAs = driver.getScreenshotAs(OutputType.FILE);
	    File destnfile=new File("./snap/shot"+random+".jpg");//empty
	    FileUtils.copyFile(screenshotAs, destnfile);
	    WebElement pass = driver.findElement(By.id("password"));
	    uname.sendKeys("crmsfa");
	  
	    
		/*
		 * File screen = driver.getScreenshotAs(OutputType.FILE); File deste=new
		 * File("./snap/shot2.jpg");//empty FileUtils.copyFile(screenshotAs, destnfile);
		 */
	    
		/*
		 * File screenshot = uname.getScreenshotAs(OutputType.FILE); File destn=new
		 * File("./snap/shot1.jpg");//empty FileUtils.copyFile(screenshot, destn);
		 * 
		 * 
		 * 
		 */	    
	}

}
