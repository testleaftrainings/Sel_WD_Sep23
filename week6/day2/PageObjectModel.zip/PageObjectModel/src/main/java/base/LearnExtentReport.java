package base;

import java.io.IOException;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

public class LearnExtentReport {

	public static void main(String[] args) throws IOException {
		//Step:1 Create a folder and Set the path of the report  
				ExtentHtmlReporter reporter=new ExtentHtmlReporter("./reports/result.html");		
				reporter.setAppendExisting(true);
				//Step:2 Create a object for ExtentReport to attach the data captured to result.html
				ExtentReports extent=new ExtentReports();
				extent.attachReporter(reporter);
				
				
				ExtentTest test = extent.createTest("Login Funtionality" ,"Login with Valid Credentials");
				test.pass("Login is successful",
						MediaEntityBuilder.createScreenCaptureFromPath(".././snap/img93951.png").build());
				test.pass("Login is not successful",
						MediaEntityBuilder.createScreenCaptureFromPath(".././snap/img93951.png").build());
				test.assignCategory("Funtional");
				test.assignAuthor("Tesjawi");
				
				//mantadory step
				extent.flush();
	}
	
}
