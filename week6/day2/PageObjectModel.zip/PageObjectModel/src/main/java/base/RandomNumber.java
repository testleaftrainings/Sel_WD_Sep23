package base;

public class RandomNumber {

	public static void main(String[] args) {
		
		int random =(int) (Math.random()*999);
		System.out.println(random);

	}

}
