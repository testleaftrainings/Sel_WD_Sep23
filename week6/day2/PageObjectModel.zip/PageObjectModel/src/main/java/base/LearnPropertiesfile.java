package base;

import java.io.FileInputStream;

import java.io.IOException;
import java.util.Properties;

public class LearnPropertiesfile {

	public static void main(String[] args) throws IOException {
		//set the path of the properties file
		FileInputStream fis=new FileInputStream("./src/main/resources/French.properties");
		
		//create Instance for the Properties class		
		Properties prop=new Properties();
		
		//connect the file with prop to read data from the given file
		prop.load(fis);		
		//get the data from properties file
		String url = prop.getProperty("url");
		System.out.println(url);		
		System.out.println(prop.getProperty("username"));
		System.out.println(prop.getProperty("password"));

	}

}
