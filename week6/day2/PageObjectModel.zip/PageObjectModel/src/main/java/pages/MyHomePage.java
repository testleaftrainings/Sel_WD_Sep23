package pages;

import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethods;

public class MyHomePage extends ProjectSpecificMethods {

	public MyHomePage(ChromeDriver driver,Properties prop) {
		this.driver=driver;
		this.prop=prop;
	}	
	
	public LeadPage clickLeads() {
		driver.findElement(By.linkText(prop.getProperty("MyHomePage.LinkText.Leads"))).click();
		return new LeadPage(driver,prop);
	}
}
