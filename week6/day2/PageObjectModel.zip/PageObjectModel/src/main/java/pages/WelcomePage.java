package pages;

import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethods;

public class WelcomePage extends ProjectSpecificMethods {
	
	public WelcomePage(ChromeDriver driver, Properties prop) {
		this.driver=driver;
		this.prop=prop;
	}

	public MyHomePage clickCRMSFA() {
		driver.findElement(By.linkText("CRM/SFA")).click();
		return new MyHomePage(driver,prop);
	}

	public LoginPage clickLogout() {
		return new LoginPage(driver,prop);
	}

	public WelcomePage verifyWelcomePage() {
		String title = driver.getTitle();
		System.out.println(title);
		System.out.println(driver.findElement(By.tagName("h2")).getText());
		//return new WelcomePage();
		return this;
	}

}
