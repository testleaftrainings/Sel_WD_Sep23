package pages;

import java.util.Properties;

import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethods;

public class LeadPage extends ProjectSpecificMethods {

	public LeadPage(ChromeDriver driver, Properties prop) {
		this.driver=driver;
		this.prop=prop;
	}
	public CreateLeadPage clickCreateLead() {
		return new CreateLeadPage(driver,prop);
	}
	
	
}
