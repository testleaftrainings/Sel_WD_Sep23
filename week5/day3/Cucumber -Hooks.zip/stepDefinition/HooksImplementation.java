package stepDefinition;

import java.time.Duration;

import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.After;
import io.cucumber.java.Before;

public class HooksImplementation extends BaseClass {

	/*
	 * @Before // run before every scenario public void preConditions() { driver =
	 * new ChromeDriver(); driver.manage().window().maximize();
	 * driver.get("http://leaftaps.com/opentaps/");
	 * driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10)); }
	 * 
	 * @After // run after scenario public void postConditions() { driver.close();
	 * 
	 * }
	 */
}
