package pages;

import base.ProjectSpecificMethod;

public class ViewLeadPage extends ProjectSpecificMethod {

}
