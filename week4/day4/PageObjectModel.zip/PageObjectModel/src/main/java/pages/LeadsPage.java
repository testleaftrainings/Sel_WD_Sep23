package pages;

import base.ProjectSpecificMethod;

public class LeadsPage extends ProjectSpecificMethod {

}
