package testcase;

import org.testng.annotations.Test;

import base.ProjectSpecificMethod;
import pages.LoginPage;
import pages.WelcomePage;

public class Logoutfuntionality extends ProjectSpecificMethod {

	@Test
	public void runLogout() {
		
		new LoginPage().enterUsername().enterPassword().clickLogin().clickLogout();
		
	}
	
}
