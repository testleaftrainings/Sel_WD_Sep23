package testcase;

import org.testng.annotations.Test;

import base.ProjectSpecificMethod;
import pages.LoginPage;

public class CreateLeads extends ProjectSpecificMethod {

	
	@Test
	public void runLogout() {
		
		new LoginPage().enterUsername().enterPassword().clickLogin().clickCrmSFA().clickLeads();
		
	}
}
